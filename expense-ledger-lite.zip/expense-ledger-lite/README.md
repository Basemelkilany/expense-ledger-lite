# Expense Ledger Lite 💜

An **offline desktop expense tracker** made with **Python, Tkinter and SQLite**. No account, API key or internet connection needed.

## Features
- Add expenses with categories, dates, payment methods and validated amounts
- Filter by month, category or search term
- Live totals for the visible expenses
- Export filtered transactions to CSV
- Create a verified SQLite backup with one click
- Store amounts as **integer cents** (not floating-point money)

## Quick start (Windows)

1. Install Python 3.11+ (the normal Python installer includes Tkinter).
2. Extract this project, open the folder and double-click `START_WINDOWS.bat`.
3. Or run `python app.py` from a terminal.

Data is stored in `%USERPROFILE%\.expense-ledger-lite\expenses.sqlite3`. To set a custom location, use the `EXPENSE_LEDGER_DB` environment variable.

## Run automated tests

```bash
python -m unittest discover -s tests -v
```

## Design decisions

- SQLite transactions persist expenses immediately, even after a restart.
- `Decimal` validates amounts before conversion to integer cents.
- The application runs **only on the user's computer**; it is not a networked accounting system.
- CSV exports are intended for personal reports, not formal financial statements.

## Limitations

No multi-currency support, bank connection, authentication or tax filing functionality. Do not use it as a production business ledger without further safeguards.

## Portfolio description

> Built an offline expense-tracking desktop application with Python Tkinter, transactional SQLite storage, reliable money handling, search/filter tools, CSV export and database backups.

MIT licensed. All example code is original. Contributions and issues welcome.
