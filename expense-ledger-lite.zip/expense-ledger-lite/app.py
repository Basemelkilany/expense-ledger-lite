"""Expense Ledger Lite — a friendly offline desktop expense tracker."""
from datetime import date
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from ledger import CATEGORIES, METHODS, ExpenseStore

BG = "#f6f7fb"
INK = "#17253c"
ACCENT = "#5b43d6"
MUTED = "#66768b"


class ExpenseApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.store = ExpenseStore()
        self.root.title("Expense Ledger Lite · Offline")
        self.root.geometry("1060x730")
        self.root.minsize(800, 610)
        self.root.configure(bg=BG)
        self.selected_id = None
        self._build()
        self.refresh()

    def _build(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview", rowheight=31, borderwidth=0, font=("Segoe UI", 10), background="white", fieldbackground="white", foreground=INK)
        style.configure("Treeview.Heading", padding=10, background="#e8ebf5", foreground=INK, font=("Segoe UI", 10, "bold"))
        style.map("Treeview", background=[("selected", "#dcd5ff")], foreground=[("selected", INK)])
        style.configure("TCombobox", padding=6)

        top = tk.Frame(self.root, bg=BG, padx=28, pady=20)
        top.pack(fill="x")
        tk.Label(top, text="EXPENSE LEDGER", bg=BG, fg=ACCENT, font=("Segoe UI", 11, "bold")).pack(anchor="w")
        tk.Label(top, text="Your money, clearly organised.", bg=BG, fg=INK, font=("Segoe UI", 23, "bold")).pack(anchor="w")
        tk.Label(top, text="Private · Works without internet · Saved automatically to SQLite", bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w")

        form = tk.LabelFrame(self.root, text="  Add an expense  ", padx=18, pady=15, bg="white", fg=INK, font=("Segoe UI", 11, "bold"), bd=0, highlightbackground="#e2e7f0", highlightthickness=1)
        form.pack(fill="x", padx=28, pady=(0, 18))
        self.date_var = tk.StringVar(value=date.today().isoformat())
        self.category_var = tk.StringVar(value=CATEGORIES[0])
        self.method_var = tk.StringVar(value=METHODS[0])
        self.desc_var = tk.StringVar()
        self.amount_var = tk.StringVar()
        inputs = [
            ("Date (YYYY-MM-DD)", ttk.Entry(form, textvariable=self.date_var, width=16)),
            ("Category", ttk.Combobox(form, values=CATEGORIES, textvariable=self.category_var, width=15, state="readonly")),
            ("Description", ttk.Entry(form, textvariable=self.desc_var, width=32)),
            ("Payment", ttk.Combobox(form, values=METHODS, textvariable=self.method_var, width=15, state="readonly")),
            ("Amount", ttk.Entry(form, textvariable=self.amount_var, width=14)),
        ]
        for i, (label, widget) in enumerate(inputs):
            tk.Label(form, text=label, fg=MUTED, bg="white", font=("Segoe UI", 9)).grid(row=0, column=i, sticky="w", padx=(0, 12), pady=(0, 5))
            widget.grid(row=1, column=i, sticky="ew", padx=(0, 12))
            form.grid_columnconfigure(i, weight=(2 if i == 2 else 1))
        tk.Button(form, text="+ Add expense", bg=ACCENT, fg="white", activebackground="#4934b2", activeforeground="white", relief="flat", padx=20, pady=10, font=("Segoe UI", 10, "bold"), command=self.add).grid(row=2, column=0, columnspan=5, sticky="w", pady=(16, 0))
        self.root.bind("<Control-Return>", lambda _: self.add())

        filter_frame = tk.Frame(self.root, bg=BG, padx=28)
        filter_frame.pack(fill="x")
        self.month_var = tk.StringVar(value=date.today().strftime("%Y-%m"))
        self.filter_category = tk.StringVar(value="All")
        self.search_var = tk.StringVar()
        tk.Label(filter_frame, text="Month", bg=BG, fg=MUTED).pack(side="left")
        ttk.Entry(filter_frame, textvariable=self.month_var, width=9).pack(side="left", padx=(6, 16))
        tk.Label(filter_frame, text="Category", bg=BG, fg=MUTED).pack(side="left")
        ttk.Combobox(filter_frame, textvariable=self.filter_category, values=("All",) + CATEGORIES, width=16, state="readonly").pack(side="left", padx=(6, 16))
        tk.Label(filter_frame, text="Search", bg=BG, fg=MUTED).pack(side="left")
        ttk.Entry(filter_frame, textvariable=self.search_var, width=25).pack(side="left", padx=(6, 16))
        ttk.Button(filter_frame, text="Apply filters", command=self.refresh).pack(side="left")
        ttk.Button(filter_frame, text="All dates", command=self.all_dates).pack(side="left", padx=(10, 0))

        totals = tk.Frame(self.root, bg=BG, padx=28, pady=15)
        totals.pack(fill="x")
        self.total_label = tk.Label(totals, text="0.00", bg=BG, fg=INK, font=("Segoe UI", 22, "bold"))
        self.total_label.pack(side="left")
        self.count_label = tk.Label(totals, text="", bg=BG, fg=MUTED, font=("Segoe UI", 10))
        self.count_label.pack(side="left", padx=18)

        tableframe = tk.Frame(self.root, bg=BG, padx=28)
        tableframe.pack(fill="both", expand=True)
        cols = ("date", "category", "description", "method", "amount")
        self.tree = ttk.Treeview(tableframe, columns=cols, show="headings", selectmode="browse")
        for c, width in zip(cols, (135, 150, 375, 160, 140)):
            self.tree.heading(c, text=c.title())
            self.tree.column(c, width=width, anchor="e" if c == "amount" else "w", stretch=True)
        yscroll = ttk.Scrollbar(tableframe, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=yscroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        yscroll.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        actions = tk.Frame(self.root, bg=BG, padx=28, pady=16)
        actions.pack(fill="x")
        ttk.Button(actions, text="Export displayed CSV", command=self.export).pack(side="left")
        ttk.Button(actions, text="Backup database", command=self.backup).pack(side="left", padx=10)
        ttk.Button(actions, text="Delete selected", command=self.delete).pack(side="right")
        tk.Label(actions, text="Currency: USD · Data saved locally", fg=MUTED, bg=BG).pack(side="right", padx=15)

    def filters(self):
        return self.month_var.get().strip(), "" if self.filter_category.get() == "All" else self.filter_category.get(), self.search_var.get().strip()

    def refresh(self):
        try:
            rows = self.store.list(*self.filters())
        except ValueError as exc:
            messagebox.showerror("Invalid filter", str(exc))
            return
        for item in self.tree.get_children():
            self.tree.delete(item)
        for item in rows:
            self.tree.insert("", "end", iid=item["id"], values=(item["expense_date"], item["category"], item["description"], item["method"], f'{item["amount_cents"] / 100:,.2f}'))
        self.total_label.config(text=f'USD {sum(row["amount_cents"] for row in rows) / 100:,.2f}')
        self.count_label.config(text=f"{len(rows)} expense(s) · filtered view")
        self.selected_id = None

    def all_dates(self):
        self.month_var.set("")
        self.refresh()

    def on_select(self, _event):
        selected = self.tree.selection()
        self.selected_id = selected[0] if selected else None

    def add(self):
        try:
            self.store.add(self.date_var.get(), self.category_var.get(), self.desc_var.get(), self.method_var.get(), self.amount_var.get())
        except ValueError as exc:
            messagebox.showerror("Check expense", str(exc))
            return
        self.desc_var.set("")
        self.amount_var.set("")
        self.refresh()

    def delete(self):
        if not self.selected_id:
            messagebox.showinfo("Select an expense", "Click a row first.")
            return
        if messagebox.askyesno("Delete expense", "Permanently delete the selected expense?"):
            self.store.delete(self.selected_id)
            self.refresh()

    def export(self):
        target = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV file", "*.csv")], initialfile="expenses.csv")
        if target:
            self.store.export_csv(target, *self.filters())
            messagebox.showinfo("Export complete", f"Saved CSV to:\n{target}")

    def backup(self):
        target = filedialog.asksaveasfilename(defaultextension=".sqlite3", filetypes=[("SQLite database", "*.sqlite3")], initialfile="expenses-backup.sqlite3")
        if target:
            try:
                self.store.backup(target)
                messagebox.showinfo("Backup complete", f"Verified database backup saved to:\n{target}")
            except (ValueError, OSError, RuntimeError) as exc:
                messagebox.showerror("Backup failed", str(exc))


if __name__ == "__main__":
    root = tk.Tk()
    ExpenseApp(root)
    root.mainloop()
