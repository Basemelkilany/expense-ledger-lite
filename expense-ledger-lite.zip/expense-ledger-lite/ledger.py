"""SQLite storage and validation for Expense Ledger Lite (standard library only)."""
from __future__ import annotations

import csv
import os
import re
import sqlite3
from contextlib import contextmanager, closing
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from uuid import uuid4

CATEGORIES = ("Food", "Transport", "Utilities", "Supplies", "Software", "Travel", "Other")
METHODS = ("Cash", "Card", "Transfer", "Other")


def default_db_path() -> Path:
    return Path(os.environ.get("EXPENSE_LEDGER_DB", str(Path.home() / ".expense-ledger-lite" / "expenses.sqlite3")))


def parse_amount(text: str) -> int:
    """Convert a positive USD-like amount to integer cents (no binary float)."""
    raw = str(text).strip().replace(",", "")
    try:
        amount = Decimal(raw)
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("Amount must be a number, e.g. 12.50") from exc
    if not amount.is_finite() or amount <= 0:
        raise ValueError("Amount must be greater than zero")
    if amount.as_tuple().exponent < -2:
        raise ValueError("Use at most two decimal places")
    cents = int((amount * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    if cents > 10**12:
        raise ValueError("Amount is too large")
    return cents


def validate_date(text: str) -> str:
    value = str(text).strip()
    try:
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
            raise ValueError("Date must use YYYY-MM-DD")
        date.fromisoformat(value)
    except ValueError as exc:
        raise ValueError("Date must be a valid YYYY-MM-DD") from exc
    return value


def safe_csv_cell(text: str) -> str:
    """Prevent spreadsheet formula execution when opening exported CSV files."""
    return "'" + text if text.lstrip().startswith(("=", "+", "-", "@")) else text


class ExpenseStore:
    def __init__(self, db_path: str | Path | None = None):
        self.path = Path(db_path) if db_path is not None else default_db_path()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init()

    @contextmanager
    def connect(self):
        conn = sqlite3.connect(self.path, timeout=15)
        try:
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA busy_timeout=15000")
            with conn:
                yield conn
        finally:
            conn.close()

    def _init(self):
        with self.connect() as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS expenses (
                id TEXT PRIMARY KEY,
                expense_date TEXT NOT NULL,
                category TEXT NOT NULL,
                description TEXT NOT NULL,
                method TEXT NOT NULL,
                amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
                created_utc TEXT NOT NULL
            )""")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date)")

    def add(self, expense_date: str, category: str, description: str, method: str, amount: str) -> str:
        expense_date = validate_date(expense_date)
        if category not in CATEGORIES:
            raise ValueError("Choose a valid category")
        if method not in METHODS:
            raise ValueError("Choose a valid payment method")
        description = description.strip()
        if not 1 <= len(description) <= 160:
            raise ValueError("Description must be 1–160 characters")
        cents = parse_amount(amount)
        record_id = uuid4().hex
        timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
        with self.connect() as conn:
            conn.execute("""INSERT INTO expenses
                (id, expense_date, category, description, method, amount_cents, created_utc)
                VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (record_id, expense_date, category, description, method, cents, timestamp))
        return record_id

    def list(self, month: str = "", category: str = "", search: str = ""):
        terms = []
        args = []
        if month:
            if len(month) != 7 or month[4] != "-" or not month[:4].isdigit() or not month[5:].isdigit() or not (1 <= int(month[5:]) <= 12):
                raise ValueError("Month must be YYYY-MM")
            terms.append("substr(expense_date,1,7)=?")
            args.append(month)
        if category:
            terms.append("category=?")
            args.append(category)
        if search:
            terms.append("(lower(description) LIKE ? OR lower(category) LIKE ?)")
            escaped = search.lower().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            terms[-1] = "(lower(description) LIKE ? ESCAPE '\\' OR lower(category) LIKE ? ESCAPE '\\')"
            args.extend([f"%{escaped}%", f"%{escaped}%"])
        statement = "SELECT * FROM expenses"
        if terms:
            statement += " WHERE " + " AND ".join(terms)
        statement += " ORDER BY expense_date DESC, created_utc DESC, id DESC"
        with self.connect() as conn:
            return [dict(row) for row in conn.execute(statement, args).fetchall()]

    def delete(self, record_id: str) -> bool:
        with self.connect() as conn:
            cursor = conn.execute("DELETE FROM expenses WHERE id=?", (record_id,))
            return cursor.rowcount == 1

    def totals_by_category(self, month: str = "") -> list[tuple[str, int]]:
        rows = self.list(month=month)
        amounts = {}
        for row in rows:
            amounts[row["category"]] = amounts.get(row["category"], 0) + row["amount_cents"]
        return sorted(amounts.items(), key=lambda entry: (-entry[1], entry[0]))

    def export_csv(self, destination: str | Path, month: str = "", category: str = "", search: str = "") -> int:
        rows = self.list(month=month, category=category, search=search)
        with open(destination, "w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.writer(handle)
            writer.writerow(["Date", "Category", "Description", "Payment Method", "Amount", "ID"])
            for row in rows:
                writer.writerow([row["expense_date"], row["category"], safe_csv_cell(row["description"]), row["method"], f'{row["amount_cents"] / 100:.2f}', row["id"]])
        return len(rows)

    def backup(self, destination: str | Path) -> Path:
        dest = Path(destination)
        if dest.resolve() == self.path.resolve():
            raise ValueError("Backup destination must be different from live database")
        dest.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as source, closing(sqlite3.connect(dest)) as target:
            with target:
                source.backup(target)
                integrity = target.execute("PRAGMA integrity_check").fetchone()[0]
                if integrity != "ok":
                    raise RuntimeError(f"Backup validation failed: {integrity}")
        return dest
