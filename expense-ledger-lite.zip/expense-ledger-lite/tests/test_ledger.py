import csv
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from ledger import ExpenseStore, parse_amount, validate_date, safe_csv_cell


class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = ExpenseStore(Path(self.tmp.name) / "test.sqlite3")

    def test_decimal_amounts(self):
        self.assertEqual(parse_amount("1,245.67"), 124567)
        for bad in ("-1", "0", "2.555", "NaN", "hello"):
            with self.subTest(value=bad), self.assertRaises(ValueError):
                parse_amount(bad)

    def test_date_validation(self):
        self.assertEqual(validate_date("2026-11-24"), "2026-11-24")
        with self.assertRaises(ValueError):
            validate_date("2026-02-30")

    def test_csv_formula_is_escaped(self):
        self.assertEqual(safe_csv_cell("=SUM(A1:A2)"), "'=SUM(A1:A2)")
        self.assertEqual(safe_csv_cell("normal text"), "normal text")

    def test_crud_and_totals(self):
        first = self.db.add("2026-11-24", "Food", "Lunch", "Cash", "12.50")
        self.db.add("2026-11-25", "Software", "Editor", "Card", "25.00")
        self.assertEqual(len(self.db.list(month="2026-11")), 2)
        self.assertEqual(sum(x["amount_cents"] for x in self.db.list()), 3750)
        self.assertEqual(self.db.totals_by_category()[0], ("Software", 2500))
        self.assertTrue(self.db.delete(first))
        self.assertFalse(self.db.delete(first))
        self.assertEqual(len(self.db.list()), 1)

    def test_filters_escape_sql_like(self):
        self.db.add("2026-01-01", "Other", "100% completed", "Cash", "4")
        self.db.add("2026-02-01", "Other", "100 things", "Cash", "5")
        self.assertEqual(len(self.db.list(search="%")), 1)
        self.assertEqual(len(self.db.list(month="2026-01")), 1)

    def test_export_and_backup(self):
        self.db.add("2026-11-24", "Food", "Tea", "Cash", "2.10")
        csv_file = Path(self.tmp.name) / "out.csv"
        self.assertEqual(self.db.export_csv(csv_file), 1)
        with open(csv_file, newline="", encoding="utf-8-sig") as file:
            self.assertEqual(list(csv.DictReader(file))[0]["Amount"], "2.10")
        backup_file = self.db.backup(Path(self.tmp.name) / "backup.sqlite3")
        with sqlite3.connect(backup_file) as conn:
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM expenses").fetchone()[0], 1)
            self.assertEqual(conn.execute("PRAGMA integrity_check").fetchone()[0], "ok")


if __name__ == "__main__":
    unittest.main()
